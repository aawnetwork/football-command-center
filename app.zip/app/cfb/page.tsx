"use client";

import { Fragment, useEffect, useMemo, useState } from "react";
import { GameCard } from "../components/GameCard";

type Game = {
  id: number;
  startDate: string;
  homeTeam: string;
  awayTeam: string;
  homePoints: number | null;
  awayPoints: number | null;
  homeRank: number | null;
  awayRank: number | null;
  completed: boolean;
};

type Milestone = {
  player: string;
  team: string;
  category: string;
  stat: string;
  value: number;
  gameId: number;
  opponent: string;
  message: string;
};

type UpsetSignal = {
  gameId: number;
  rank: number;
  rankedTeam: string;
  opponent: string;
  result: string;
};

const rivalries = [
  {
    teams: ["Michigan", "Ohio State"],
    name: "The Game",
    trophy: null,
  },
  {
    teams: ["Illinois", "Ohio State"],
    name: "Illibuck",
    trophy: "Illibuck",
  },
  {
    teams: ["Minnesota", "Wisconsin"],
    name: "Paul Bunyan's Axe",
    trophy: "Paul Bunyan's Axe",
  },
  {
    teams: ["Iowa", "Minnesota"],
    name: "Floyd of Rosedale",
    trophy: "Floyd of Rosedale",
  },
  {
    teams: ["Indiana", "Purdue"],
    name: "Old Oaken Bucket",
    trophy: "Old Oaken Bucket",
  },
  {
    teams: ["Michigan", "Michigan State"],
    name: "Paul Bunyan Trophy",
    trophy: "Paul Bunyan Trophy",
  },
  {
    teams: ["Iowa", "Iowa State"],
    name: "Cy-Hawk Series",
    trophy: "Cy-Hawk Trophy",
  },
  {
    teams: ["Nebraska", "Iowa"],
    name: "Heroes Game",
    trophy: "Heroes Trophy",
  },
  {
    teams: ["Penn State", "Michigan State"],
    name: "Land Grant Trophy",
    trophy: "Land Grant Trophy",
  },
  {
    teams: ["Penn State", "Pittsburgh"],
    name: "Keystone Classic",
    trophy: null,
  },
  {
    teams: ["Wisconsin", "Nebraska"],
    name: "Freedom Trophy",
    trophy: "Freedom Trophy",
  },
  {
    teams: ["Oregon", "Oregon State"],
    name: "Civil War",
    trophy: null,
  },
  {
    teams: ["Oregon", "Washington"],
    name: "Border War",
    trophy: null,
  },
  {
    teams: ["Washington", "Washington State"],
    name: "Apple Cup",
    trophy: "Apple Cup",
  },
  {
    teams: ["USC", "UCLA"],
    name: "Crosstown Showdown",
    trophy: "Victory Bell",
  },
  {
    teams: ["USC", "Notre Dame"],
    name: "Notre Dame–USC Rivalry",
    trophy: "Jeweled Shillelagh",
  },
  {
    teams: ["Stanford", "California"],
    name: "The Big Game",
    trophy: "Stanford Axe",
  },
  {
    teams: ["UCLA", "California"],
    name: "UCLA–Cal Rivalry",
    trophy: null,
  },
  {
    teams: ["Oregon", "Stanford"],
    name: "Northwest Rivalry",
    trophy: null,
  },
  {
    teams: ["Utah", "BYU"],
    name: "Holy War",
    trophy: null,
  },
  {
    teams: ["Arizona", "Arizona State"],
    name: "Territorial Cup",
    trophy: "Territorial Cup",
  },
  {
    teams: ["Colorado", "Colorado State"],
    name: "Rocky Mountain Showdown",
    trophy: "Centennial Cup",
  },
  {
    teams: ["Colorado", "Nebraska"],
    name: "Colorado–Nebraska Rivalry",
    trophy: null,
  },
  {
    teams: ["Alabama", "Auburn"],
    name: "Iron Bowl",
    trophy: null,
  },
  {
    teams: ["Alabama", "Tennessee"],
    name: "Third Saturday in October",
    trophy: "Third Saturday in October Trophy",
  },
  {
    teams: ["Alabama", "LSU"],
    name: "Alabama–LSU Rivalry",
    trophy: null,
  },
  {
    teams: ["Auburn", "Georgia"],
    name: "Deep South's Oldest Rivalry",
    trophy: null,
  },
  {
    teams: ["Georgia", "Florida"],
    name: "World's Largest Outdoor Cocktail Party",
    trophy: null,
  },
  {
    teams: ["Georgia", "Georgia Tech"],
    name: "Clean, Old-Fashioned Hate",
    trophy: null,
  },
  {
    teams: ["Florida", "Florida State"],
    name: "Sunshine Showdown",
    trophy: null,
  },
  {
    teams: ["Florida", "Tennessee"],
    name: "Florida–Tennessee Rivalry",
    trophy: null,
  },
  {
    teams: ["LSU", "Arkansas"],
    name: "Battle for the Golden Boot",
    trophy: "Golden Boot",
  },
  {
    teams: ["LSU", "Texas A&M"],
    name: "Texas A&M–LSU Rivalry",
    trophy: "The Boot",
  },
  {
    teams: ["Ole Miss", "Mississippi State"],
    name: "Egg Bowl",
    trophy: "Golden Egg",
  },
  {
    teams: ["Missouri", "Arkansas"],
    name: "Battle Line Rivalry",
    trophy: "Battle Line Trophy",
  },
  {
    teams: ["Texas", "Oklahoma"],
    name: "Red River Rivalry",
    trophy: "Golden Hat",
  },
  {
    teams: ["Oklahoma", "Oklahoma State"],
    name: "Bedlam",
    trophy: null,
  },
  {
    teams: ["Texas", "Texas A&M"],
    name: "Lone Star Showdown",
    trophy: null,
  },
  {
    teams: ["Texas", "Texas Tech"],
    name: "Texas–Texas Tech Rivalry",
    trophy: null,
  },
  {
    teams: ["Texas A&M", "LSU"],
    name: "Texas A&M–LSU Rivalry",
    trophy: "The Boot",
  },
  {
    teams: ["Kansas", "Kansas State"],
    name: "Sunflower Showdown",
    trophy: null,
  },
  {
    teams: ["Kansas", "Missouri"],
    name: "Border War",
    trophy: null,
  },
  {
    teams: ["Kansas State", "Iowa State"],
    name: "Farmageddon",
    trophy: null,
  },
  {
    teams: ["Nebraska", "Oklahoma"],
    name: "Nebraska–Oklahoma Rivalry",
    trophy: null,
  },
  {
    teams: ["Florida State", "Miami"],
    name: "Miami–Florida State Rivalry",
    trophy: null,
  },
  {
    teams: ["Florida State", "Clemson"],
    name: "Florida State–Clemson Rivalry",
    trophy: null,
  },
  {
    teams: ["Clemson", "South Carolina"],
    name: "Palmetto Bowl",
    trophy: "Palmetto Bowl Trophy",
  },
  {
    teams: ["North Carolina", "Duke"],
    name: "Carolina–Duke Rivalry",
    trophy: null,
  },
  {
    teams: ["North Carolina", "NC State"],
    name: "Carolina–NC State Rivalry",
    trophy: null,
  },
  {
    teams: ["Virginia", "Virginia Tech"],
    name: "Commonwealth Clash",
    trophy: null,
  },
  {
    teams: ["Virginia Tech", "West Virginia"],
    name: "Black Diamond Trophy",
    trophy: "Black Diamond Trophy",
  },
  {
    teams: ["Pittsburgh", "West Virginia"],
    name: "Backyard Brawl",
    trophy: null,
  },
  {
    teams: ["Pittsburgh", "Syracuse"],
    name: "Pittsburgh–Syracuse Rivalry",
    trophy: null,
  },
  {
    teams: ["Boston College", "Notre Dame"],
    name: "Franklin Trophy",
    trophy: "Franklin Trophy",
  },
  {
    teams: ["Army", "Navy"],
    name: "Army–Navy Game",
    trophy: null,
  },
  {
    teams: ["Notre Dame", "Navy"],
    name: "Notre Dame–Navy Rivalry",
    trophy: null,
  },
  {
    teams: ["Harvard", "Yale"],
    name: "The Game",
    trophy: null,
  },
  {
    teams: ["Princeton", "Yale"],
    name: "Princeton–Yale Rivalry",
    trophy: null,
  },
  {
    teams: ["Boise State", "Fresno State"],
    name: "Battle for the Milk Can",
    trophy: "Milk Can",
  },
  {
    teams: ["Boise State", "Nevada"],
    name: "Boise State–Nevada Rivalry",
    trophy: null,
  },
  {
    teams: ["Fresno State", "San Diego State"],
    name: "Oil Can",
    trophy: "Oil Can",
  },
  {
    teams: ["Air Force", "Colorado State"],
    name: "Ram–Falcon Trophy",
    trophy: "Ram–Falcon Trophy",
  },
  {
    teams: ["Wyoming", "Colorado State"],
    name: "Border War",
    trophy: "Bronze Boot",
  },
  {
    teams: ["BYU", "Utah"],
    name: "Holy War",
    trophy: null,
  },
  {
    teams: ["Cincinnati", "Louisville"],
    name: "Keg of Nails",
    trophy: "Keg of Nails",
  },
  {
    teams: ["Cincinnati", "Pittsburgh"],
    name: "River City Rivalry",
    trophy: null,
  },
  {
    teams: ["UCF", "South Florida"],
    name: "War on I-4",
    trophy: null,
  },
  {
    teams: ["Houston", "Rice"],
    name: "Bayou Bucket",
    trophy: "Bayou Bucket",
  },
  {
    teams: ["Memphis", "Southern Methodist"],
    name: "Battle for the Iron Skillet",
    trophy: "Iron Skillet",
  },
  {
    teams: ["Appalachian State", "Georgia Southern"],
    name: "Appalachian State–Georgia Southern Rivalry",
    trophy: null,
  },
  {
    teams: ["Marshall", "Western Kentucky"],
    name: "The Moonshine Throwdown",
    trophy: null,
  },
  {
    teams: ["East Carolina", "NC State"],
    name: "Textile Bowl",
    trophy: null,
  },
];

type SeasonStat = {
  id: string;
  name: string;
  team: string;
  category: string;
  statType: string;
  stat: number;
  type: "individual" | "team";
};

type PlayerStat = {
  playerId: number;
  player: string;
  team: string;
  category:
    | "passing"
    | "rushing"
    | "receiving"
    | "defensive";
  stat:
    | "YDS"
    | "TD"
    | "INT"
    | "TOT"
    | "SACKS"
    | "TFL"
    | "PD";
  value: number;
  gameId: number;
  opponent: string;
};

type Tier = "S" | "A" | "B" | "C" | "D";

type Leader = {
  playerId: string;
  player: string;
  team: string;
  value: number;
};

type BigPerformance = {
  id: string;
  playerId: number;
  player: string;
  team: string;
  reason: string;
  gameId: number;
  opponent: string;
  stats: PlayerStat[];
};

type StatsMode = "season" | "weekly";

type WeeklyCategory = {
  id: string;
  name: string;
};

const tierInfo: Record<
  Tier,
  { name: string; emoji: string }
> = {
  S: { name: "Must Watch", emoji: "🔥" },
  A: { name: "High Interest", emoji: "👀" },
  B: { name: "Worth Watching", emoji: "📺" },
  C: { name: "Background", emoji: "🟢" },
  D: { name: "Skip", emoji: "⚪" },
};

const individualCategories = [
  { id: "rushing", name: "Rushing Yards" },
  { id: "rushing-td", name: "Rushing TDs" },
  { id: "passing", name: "Passing Yards" },
  { id: "passing-td", name: "Passing TDs" },
  { id: "receiving", name: "Receiving Yards" },
  { id: "receiving-td", name: "Receiving TDs" },
  { id: "tackles", name: "Total Tackles" },
  { id: "sacks", name: "Sacks" },
];

const teamCategories = [
  { id: "total-offense", name: "Total Offense" },
  { id: "rushing-offense", name: "Rushing Offense" },
  { id: "passing-offense", name: "Passing Offense" },
  { id: "scoring-offense", name: "Scoring Offense" },
  { id: "total-defense", name: "Total Defense" },
  { id: "rushing-defense", name: "Rushing Defense" },
  { id: "passing-defense", name: "Passing Defense" },
  { id: "scoring-defense", name: "Scoring Defense" },
  { id: "sacks", name: "Sacks" },
  { id: "turnover-margin", name: "Turnover Margin" },
];

const weeklyIndividualCategories: WeeklyCategory[] = [
  { id: "rushing", name: "Rushing" },
  { id: "passing", name: "Passing" },
  { id: "receiving", name: "Receiving" },
];

const weeklyTeamCategories: WeeklyCategory[] = [
  { id: "rushing", name: "Rushing Yards" },
  { id: "passing", name: "Passing Yards" },
  { id: "receiving", name: "Receiving Yards" },
  { id: "tackles", name: "Total Tackles" },
  { id: "sacks", name: "Sacks" },
  { id: "tfl", name: "Tackles For Loss" },
  { id: "passes-defended", name: "Passes Defended" },
  { id: "defensive-td", name: "Defensive TDs" },
];

const defensiveCategories = new Set([
  "total-defense",
  "rushing-defense",
  "passing-defense",
  "scoring-defense",
]);

function getGameStatus(game: Game) {
  if (game.completed) {
    return "FINAL";
  }

  return new Date() >= new Date(game.startDate)
    ? "LIVE"
    : "SCHEDULED";
}

function formatGameTime(dateString: string) {
  return new Date(dateString).toLocaleTimeString([], {
    hour: "numeric",
    minute: "2-digit",
  });
}

function buildIndividualLeaders(
  stats: SeasonStat[],
  category: string
): Leader[] {
  const categoryMap: Record<
  string,
  {
    sourceCategory: string;
    statType: string;
  }
> = {
  rushing: {
    sourceCategory: "rushing",
    statType: "YDS",
  },
  "rushing-td": {
    sourceCategory: "rushing",
    statType: "TD",
  },
  passing: {
    sourceCategory: "passing",
    statType: "YDS",
  },
  "passing-td": {
    sourceCategory: "passing",
    statType: "TD",
  },
  receiving: {
    sourceCategory: "receiving",
    statType: "YDS",
  },
  "receiving-td": {
    sourceCategory: "receiving",
    statType: "TD",
  },
  tackles: {
    sourceCategory: "tackles",
    statType: "TACKLES",
  },
  sacks: {
    sourceCategory: "sacks",
    statType: "SACKS",
  },
};

  const selected =
    categoryMap[category];

  if (!selected) {
    return [];
  }

  return stats
    .filter(
      (stat) =>
        stat.type === "individual" &&
        stat.category ===
          selected.sourceCategory &&
        stat.statType ===
          selected.statType
    )
    .map((stat) => ({
      playerId: String(stat.id),
      player: stat.name,
      team: stat.team,
      value: Number(stat.stat) || 0,
    }))
    .sort((a, b) => b.value - a.value);
}

function buildTeamLeaders(
  stats: SeasonStat[],
  category: string
): Leader[] {
  const leaders = stats
    .filter(
      (stat) =>
        stat.type === "team" &&
        stat.category === category
    )
    .map((stat) => ({
      playerId: String(stat.id ?? stat.team),
      player: stat.team,
      team: stat.team,
      value: Number(stat.stat) || 0,
    }));

  return leaders.sort((a, b) => {
    if (defensiveCategories.has(category)) {
      return a.value - b.value;
    }

    return b.value - a.value;
  });
}

function buildWeeklyIndividualLeaders(
  stats: PlayerStat[],
  category: string
): Leader[] {
  return stats
    .filter(
      (stat) =>
        stat.category === category &&
        stat.stat === "YDS"
    )
    .map((stat) => ({
      playerId: `${stat.playerId}-${stat.gameId}`,
      player: stat.player,
      team: stat.team,
      value: Number(stat.value) || 0,
    }))
    .sort((a, b) => b.value - a.value);
}

function buildWeeklyTeamLeaders(
  stats: PlayerStat[],
  category: string
): Leader[] {
  const totals = new Map<string, number>();

  const defensiveStatMap: Record<string, string> = {
    tackles: "TOT",
    sacks: "SACKS",
    tfl: "TFL",
    "passes-defended": "PD",
    "defensive-td": "TD",
  };

  for (const stat of stats) {
    const isOffensive =
      category === "rushing" ||
      category === "passing" ||
      category === "receiving";

    if (isOffensive) {
      if (
        stat.category !== category ||
        stat.stat !== "YDS"
      ) {
        continue;
      }
    } else {
      if (
        stat.category !== "defensive" ||
        stat.stat !== defensiveStatMap[category]
      ) {
        continue;
      }
    }

    totals.set(
      stat.team,
      (totals.get(stat.team) ?? 0) +
        Number(stat.value || 0)
    );
  }

  return Array.from(totals.entries())
    .map(([team, value]) => ({
      playerId: `weekly-${category}-${team}`,
      player: team,
      team,
      value,
    }))
    .sort((a, b) => b.value - a.value);
}

function formatStatValue(
  category: string,
  value: number
) {
  if (
    category === "scoring-offense" ||
    category === "scoring-defense"
  ) {
    return `${value.toFixed(1)} PPG`;
  }

  if (category === "turnover-margin") {
    return value > 0
      ? `+${value}`
      : String(value);
  }

  if (category === "sacks") {
    return `${value.toLocaleString()} sacks`;
  }

  if (category === "tackles") {
    return `${value.toLocaleString()} tackles`;
  }

  if (category === "tfl") {
    return `${value.toLocaleString()} TFL`;
  }

  if (category === "passes-defended") {
    return `${value.toLocaleString()} passes defended`;
  }

  if (category === "defensive-td") {
    return `${value.toLocaleString()} TD`;
  }

  if (
    category === "total-defense" ||
    category === "rushing-defense" ||
    category === "passing-defense"
  ) {
    return `${value.toLocaleString()} YPG`;
  }

  if (
    category === "rushing" ||
    category === "passing" ||
    category === "receiving" ||
    category === "total-offense" ||
    category === "rushing-offense" ||
    category === "passing-offense"
  ) {
    return `${value.toLocaleString()} yards`;
  }

  if (
    category === "rushing-td" ||
    category === "passing-td" ||
    category === "receiving-td"
  ) {
    return `${value.toLocaleString()} TD`;
  }

  return value.toLocaleString();
}

function getBigPerformanceReason(
  stats: PlayerStat[]
): string | null {
  const passingYards = stats.find(
    (stat) =>
      stat.category === "passing" &&
      stat.stat === "YDS"
  );

  const rushingYards = stats.find(
    (stat) =>
      stat.category === "rushing" &&
      stat.stat === "YDS"
  );

  const receivingYards = stats.find(
    (stat) =>
      stat.category === "receiving" &&
      stat.stat === "YDS"
  );

  const passingTDs = stats.find(
    (stat) =>
      stat.category === "passing" &&
      stat.stat === "TD"
  );

  const rushingTDs = stats.find(
    (stat) =>
      stat.category === "rushing" &&
      stat.stat === "TD"
  );

  const receivingTDs = stats.find(
    (stat) =>
      stat.category === "receiving" &&
      stat.stat === "TD"
  );

  const totalTDs =
    (passingTDs?.value ?? 0) +
    (rushingTDs?.value ?? 0) +
    (receivingTDs?.value ?? 0);

  if ((passingYards?.value ?? 0) >= 400) {
    return `${passingYards?.value} passing yards`;
  }

  if ((rushingYards?.value ?? 0) >= 200) {
    return `${rushingYards?.value} rushing yards`;
  }

  if ((receivingYards?.value ?? 0) >= 200) {
    return `${receivingYards?.value} receiving yards`;
  }

  if (totalTDs >= 4) {
    return `${totalTDs} total touchdowns`;
  }

  return null;
}

function buildBigPerformances(
  stats: PlayerStat[]
): BigPerformance[] {
  const players = new Map<
    string,
    PlayerStat[]
  >();

  for (const stat of stats) {
    const key = `${stat.playerId}-${stat.player}-${stat.team}-${stat.gameId}`;

    if (!players.has(key)) {
      players.set(key, []);
    }

    players.get(key)!.push(stat);
  }

  return Array.from(players.entries())
    .map(([key, playerStats]) => {
      const reason =
        getBigPerformanceReason(playerStats);

      if (!reason) {
        return null;
      }

      const first = playerStats[0];

      return {
        id: key,
        playerId: first.playerId,
        player: first.player,
        team: first.team,
        reason,
        gameId: first.gameId,
        opponent: first.opponent,
        stats: playerStats,
      };
    })
    .filter(
      (
        performance
      ): performance is BigPerformance =>
        performance !== null
    );
}

function formatPlayerStat(
  stat: PlayerStat
) {
  if (stat.stat === "YDS") {
    return `${stat.value} yards`;
  }

  if (stat.stat === "TD") {
    return `${stat.value} TD`;
  }

  if (stat.stat === "INT") {
    return `${stat.value} INT`;
  }

  return String(stat.value);
}

function getStatLabel(
  stat: PlayerStat
) {
  const category =
    stat.category.charAt(0).toUpperCase() +
    stat.category.slice(1);

  if (stat.stat === "YDS") {
    return `${category} Yards`;
  }

  if (stat.stat === "TD") {
    return `${category} TD`;
  }

  if (stat.stat === "INT") {
    return `${category} INT`;
  }

  return `${category} ${stat.stat}`;
}

export default function Home() {
  const [activeTab, setActiveTab] =
    useState("games");

  const [games, setGames] = useState<Game[]>([]);
  const [upsets, setUpsets] = useState<UpsetSignal[]>([]);
  const [milestones, setMilestones] = useState<Milestone[]>([]);
  const [rivalryGames, setRivalryGames] = useState<
    {
      game: Game;
      rivalry: (typeof rivalries)[number];
    }[]
  >([]);
  const [gamesLoading, setGamesLoading] =
    useState(true);

  const [tiers, setTiers] =
    useState<Record<number, Tier>>({});
  const [tiersLoaded, setTiersLoaded] =
    useState(false);
  const [selectedTier, setSelectedTier] =
    useState("ALL");

  const [statsMode, setStatsMode] =
    useState<StatsMode>("season");

  const [statsView, setStatsView] =
    useState<"individual" | "team">(
      "individual"
    );

  const [selectedCategory, setSelectedCategory] =
    useState("rushing");

  const [seasonStats, setSeasonStats] =
    useState<SeasonStat[]>([]);
  const [seasonStatsLoading, setSeasonStatsLoading] =
    useState(true);

  const [playerStats, setPlayerStats] =
    useState<PlayerStat[]>([]);
  const [playerStatsLoading, setPlayerStatsLoading] =
    useState(true);

  function isRivalryGame(game: Game) {
    const normalizeTeam = (team: string) =>
      team
        .toLowerCase()
        .replace(
          /\b(wildcats|buckeyes|wolverines|spartans|fighting irish|trojans|bruins|ducks|huskies|tigers|bulldogs|gators|crimson tide|longhorns|sooners|cowboys|aggies|volunteers|seminoles|hurricanes|tar heels|blue devils|hokies|panthers|orange|eagles|cardinals|knights|owls|pirates|mountaineers|wolfpack|cavaliers|razorbacks|rebels|commodores|volunteers|gamecocks|golden bears|cardinal|beavers|buffaloes|utes|cougars|broncos|bulldogs|red raiders|jayhawks|cyclones|cornhuskers|hawkeyes|badgers|gophers|boilermakers|hoosiers|terrapins|nittany lions)\b/g,
          ""
        )
        .trim();

    const home = normalizeTeam(game.homeTeam);
    const away = normalizeTeam(game.awayTeam);

    return rivalries.find((rivalry) => {
      const [teamA, teamB] = rivalry.teams;

      const a = normalizeTeam(teamA);
      const b = normalizeTeam(teamB);

      return (
        (home.includes(a) && away.includes(b)) ||
        (home.includes(b) && away.includes(a))
      );
    });
  }

  function detectMilestones(
    playerStats: PlayerStat[]
  ) {
    return playerStats
      .filter((stat) => {
        if (stat.stat === "YDS") {
          return (
            (stat.category === "rushing" &&
              stat.value >= 200) ||
            (stat.category === "receiving" &&
              stat.value >= 200) ||
            (stat.category === "passing" &&
              stat.value >= 400)
          );
        }

        if (stat.stat === "TD") {
          return stat.value >= 4;
        }

        return false;
      })
      .map((stat) => {
        let message = "";

        if (
          stat.category === "rushing" &&
          stat.stat === "YDS"
        ) {
          message = `${stat.value} rushing yards`;
        } else if (
          stat.category === "receiving" &&
          stat.stat === "YDS"
        ) {
          message = `${stat.value} receiving yards`;
        } else if (
          stat.category === "passing" &&
          stat.stat === "YDS"
        ) {
          message = `${stat.value} passing yards`;
        } else if (stat.stat === "TD") {
          message = `${stat.value} total touchdowns`;
        }

        return {
          player: stat.player,
          team: stat.team,
          category: stat.category,
          stat: stat.stat,
          value: stat.value,
          gameId: stat.gameId,
          opponent: stat.opponent,
          message,
        };
      });
  }

  function detectUpsets(games: Game[]) {
    return games
      .filter(
        (game) =>
          ((game.homeRank &&
            game.homeRank < 26 &&
            game.homePoints !== null &&
            game.awayPoints !== null &&
            game.awayPoints > game.homePoints) ||
            (game.awayRank &&
              game.awayRank < 26 &&
              game.homePoints !== null &&
              game.awayPoints !== null &&
              game.homePoints > game.awayPoints))
      )
      .map((game) => {
        const homeLost =
          game.homeRank &&
          game.homeRank < 26 &&
          game.homePoints! < game.awayPoints!;

        const rank = homeLost
          ? game.homeRank!
          : game.awayRank!;

        const rankedTeam = homeLost
          ? game.homeTeam
          : game.awayTeam;

        const opponent = homeLost
          ? game.awayTeam
          : game.homeTeam;

        const result = homeLost
          ? `${game.awayPoints}-${game.homePoints}`
          : `${game.homePoints}-${game.awayPoints}`;

        return {
          gameId: game.id,
          rank,
          rankedTeam,
          opponent,
          result,
        };
      });
  }

  useEffect(() => {
    const savedTiers =
      localStorage.getItem(
        "cfb-game-tiers"
      );

    if (savedTiers) {
      setTiers(JSON.parse(savedTiers));
    }

    setTiersLoaded(true);
  }, []);

  useEffect(() => {
    if (!tiersLoaded) {
      return;
    }

    localStorage.setItem(
      "cfb-game-tiers",
      JSON.stringify(tiers)
    );
  }, [tiers, tiersLoaded]);

  useEffect(() => {
    async function loadGames() {
      try {
        const response = await fetch(
          "/api/scoreboard"
        );

        if (!response.ok) {
          throw new Error(
            "Failed to load games"
          );
        }

        const data = await response.json();

        setGames(data);

        setRivalryGames(
          data
            .map((game: Game): {
  game: Game;
  rivalry: (typeof rivalries)[number];
} | null => {

  const rivalry =

    isRivalryGame(game);

              if (!rivalry) {
                return null;
              }

              return {
                game,
                rivalry,
              };
            })
            .filter(
  (
    item: {
      game: Game;
      rivalry: (typeof rivalries)[number];
    } | null
  ): item is {
    game: Game;
    rivalry: (typeof rivalries)[number];
  } => item !== null
)
        );

        setUpsets(detectUpsets(data));
      } catch (error) {
        console.error(error);
      } finally {
        setGamesLoading(false);
      }
    }

    loadGames();

    const interval = setInterval(
      loadGames,
      30000
    );

    return () =>
      clearInterval(interval);
  }, []);

  useEffect(() => {
    async function loadSeasonStats() {
      try {
        const response = await fetch(
          "/api/season-stats"
        );

        if (!response.ok) {
          throw new Error(
            "Failed to load season stats"
          );
        }

        const data = await response.json();
        setSeasonStats(data);
      } catch (error) {
        console.error(error);
      } finally {
        setSeasonStatsLoading(false);
      }
    }

      loadSeasonStats();
}, [statsMode]);

  useEffect(() => {
    async function loadPlayerStats() {
      try {
        const response = await fetch(
          "/api/player-stats"
        );

        if (!response.ok) {
          throw new Error(
            "Failed to load player stats"
          );
        }

        const data = await response.json();

        setPlayerStats(data);
        setMilestones(
          detectMilestones(data)
        );
      } catch (error) {
        console.error(error);
      } finally {
        setPlayerStatsLoading(false);
      }
    }

    loadPlayerStats();

    const interval = setInterval(
      loadPlayerStats,
      30000
    );

    return () =>
      clearInterval(interval);
  }, []);

  const gamesWithSignals = useMemo(() => {
    return games.map((game) => {
      const homeLost =
        game.completed &&
        game.homePoints !== null &&
        game.awayPoints !== null &&
        game.homePoints < game.awayPoints;

      const awayLost =
        game.completed &&
        game.homePoints !== null &&
        game.awayPoints !== null &&
        game.awayPoints < game.homePoints;

      const rankedTeamLost =
        (homeLost && game.homeRank !== null) ||
        (awayLost && game.awayRank !== null);

      const rankedMatchup =
        game.homeRank !== null &&
        game.awayRank !== null;

      const top10Matchup =
        game.homeRank !== null &&
        game.awayRank !== null &&
        game.homeRank <= 10 &&
        game.awayRank <= 10;

      const top10VsUnranked =
        (game.homeRank !== null &&
          game.homeRank <= 10 &&
          game.awayRank === null) ||
        (game.awayRank !== null &&
          game.awayRank <= 10 &&
          game.homeRank === null);

      const rankedTeam =
        game.homeRank !== null ||
        game.awayRank !== null;

      let suggestedTier: Tier = "D";

      if (rankedTeamLost) {
        suggestedTier = "S";
      } else if (top10Matchup) {
        suggestedTier = "S";
      } else if (top10VsUnranked) {
        suggestedTier = "A";
      } else if (rankedMatchup) {
        suggestedTier = "A";
      } else if (rankedTeam) {
        suggestedTier = "B";
      }

      return {
        ...game,
        tier: tiers[game.id] ?? null,
        suggestedTier,
        rankedTeamLost,
        rankedMatchup,
        top10Matchup,
        top10VsUnranked,
      };
    });
  }, [games, tiers]);

  const filteredGames = useMemo(() => {
    if (selectedTier === "ALL") {
      return gamesWithSignals;
    }

    return gamesWithSignals.filter(
      (game) => game.tier === selectedTier
    );
  }, [
    gamesWithSignals,
    selectedTier,
  ]);

  const leaders = useMemo(() => {
    if (statsMode === "weekly") {
      if (statsView === "team") {
        return buildWeeklyTeamLeaders(
          playerStats,
          selectedCategory
        );
      }

      return buildWeeklyIndividualLeaders(
        playerStats,
        selectedCategory
      );
    }

    if (statsView === "team") {
      return buildTeamLeaders(
        seasonStats,
        selectedCategory
      );
    }

    return buildIndividualLeaders(
      seasonStats,
      selectedCategory
    );
  }, [
    seasonStats,
    playerStats,
    statsMode,
    statsView,
    selectedCategory,
  ]);

  const bigPerformances = useMemo(() => {
    return buildBigPerformances(
      playerStats
    );
  }, [playerStats]);

  const currentCategories =
    statsMode === "weekly"
      ? statsView === "team"
        ? weeklyTeamCategories
        : weeklyIndividualCategories
      : statsView === "team"
        ? teamCategories
        : individualCategories;

  function setGameTier(
    gameId: number,
    tier: Tier
  ) {
    setTiers((current) => {
      const next = { ...current };

      if (next[gameId] === tier) {
        delete next[gameId];
      } else {
        next[gameId] = tier;
      }

      return next;
    });
  }

  function getPerformanceResult(
    performance: BigPerformance
  ) {
    const game = games.find(
      (candidate) =>
        candidate.id === performance.gameId
    );

    if (!game) {
      return "Game status unavailable";
    }

    if (!game.completed) {
      return "Game in progress";
    }

    if (
      game.homePoints === null ||
      game.awayPoints === null
    ) {
      return "FINAL";
    }

    const normalize = (name: string) =>
      name
        .toLowerCase()
        .replace(
          /\b(tigers|wildcats|bulldogs|hoosiers|nittany lions|fighting illini|crimson tide|buckeyes|wolverines|trojans|gators|longhorns|volunteers|hurricanes|seminoles|cardinals|tar heels|blue devils|demon deacons|huskies|ducks|beavers|bruins|knights|cougars|mustangs|raiders|red raiders|owls|eagles|bears|horned frogs|cowboys|sooners|jayhawks|cyclones|mountaineers|hokies|cavaliers|orange|wolfpack|razorbacks|rebels|commodores|aggies|gamecocks|spartans|terrapins)\b/g,
          ""
        )
        .replace(/[^a-z0-9]/g, "");

    const performanceTeam =
      normalize(performance.team);

    const homeTeam =
      normalize(game.homeTeam);

    const awayTeam =
      normalize(game.awayTeam);

    const teamIsHome =
      homeTeam.includes(performanceTeam) ||
      performanceTeam.includes(homeTeam);

    const teamIsAway =
      awayTeam.includes(performanceTeam) ||
      performanceTeam.includes(awayTeam);

    if (!teamIsHome && !teamIsAway) {
      return "Result unavailable";
    }

    const teamScore = teamIsHome
      ? game.homePoints
      : game.awayPoints;

    const opponentScore = teamIsHome
      ? game.awayPoints
      : game.homePoints;

    if (teamScore > opponentScore) {
      return `WIN ${teamScore}-${opponentScore}`;
    }

    if (teamScore < opponentScore) {
      return `LOSS ${teamScore}-${opponentScore}`;
    }

    return `TIE ${teamScore}-${opponentScore}`;
  }

  function changeStatsView(
    view: "individual" | "team"
  ) {
    setStatsView(view);

    if (statsMode === "weekly") {
      setSelectedCategory(
        view === "team"
          ? "rushing"
          : "rushing"
      );
      return;
    }

    setSelectedCategory(
      view === "team"
        ? "total-offense"
        : "rushing"
    );
  }

  function changeStatsMode(
    mode: StatsMode
  ) {
    setStatsMode(mode);

    if (mode === "weekly") {
      setSelectedCategory("rushing");
    } else {
      setSelectedCategory(
        statsView === "team"
          ? "total-offense"
          : "rushing"
      );
    }
  }

  const weeklyUnavailable = false;
  const showMilestones = false;

  return (
    <main
      className="command-center command-center--cfb"
      style={{
        minHeight: "100vh",
        background: "#020617",
        color: "#f8fafc",
        padding: "32px",
        fontFamily:
          "Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, sans-serif",
      }}
    >
      <div
        className="command-center__container"
        style={{
          maxWidth: "1400px",
          margin: "0 auto",
        }}
      >
        <header
          className="command-center__header"
          style={{
            marginBottom: "28px",
          }}
        >
          <div
            className="command-center__header-content"
            style={{
              display: "flex",
              justifyContent:
                "space-between",
              alignItems:
                "flex-start",
              gap: "20px",
              flexWrap: "wrap",
            }}
          >
            <div>
              <div className="command-center__eyebrow">
                FOOTBALL COMMAND CENTER
              </div>
              <h1
                className="command-center__title"
                style={{
                  fontSize: "36px",
                  fontWeight: 800,
                  margin: 0,
                }}
              >
                CFB Command Center
              </h1>

              <p
                className="command-center__subtitle"
                style={{
                  color: "#94a3b8",
                  marginTop: "8px",
                  marginBottom: 0,
                }}
              >
                Your Saturday college
                football control room.
              </p>
            </div>

            <div
              className="command-center__source"
              style={{
                padding: "10px 14px",
                borderRadius: "10px",
                background: "#0f172a",
                border:
                  "1px solid #1e293b",
                color: "#94a3b8",
                fontSize: "14px",
              }}
            >
              Live data powered by ESPN
            </div>
          </div>
        </header>

        <nav
          className="command-center__nav"
          style={{
            display: "flex",
            gap: "8px",
            flexWrap: "wrap",
            marginBottom: "24px",
          }}
        >
          {[
  ["games", "🏈 Games"],
  ["performances", "🔥 Performances"],
  ["stats", "📊 Stats"],
  ["all-time", "🏆 All-Time"],
].map(([id, label]) => (
            <button
              key={id}
              aria-pressed={activeTab === id}
              onClick={() =>
                setActiveTab(id)
              }
              style={{
                border:
                  "1px solid #334155",
                background:
                  activeTab === id
                    ? "#1e293b"
                    : "#0f172a",
                color: "#f8fafc",
                padding:
                  "10px 16px",
                borderRadius: "8px",
                cursor: "pointer",
                fontWeight: 700,
              }}
            >
              {label}
            </button>
          ))}
        </nav>

        {activeTab === "games" && (
          <section>
            <div
              style={{
                display: "flex",
                gap: "8px",
                flexWrap: "wrap",
                marginBottom: "20px",
              }}
            >
              <button
                aria-pressed={selectedTier === "ALL"}
                onClick={() =>
                  setSelectedTier("ALL")
                }
                style={{
                  padding: "8px 14px",
                  borderRadius: "8px",
                  border:
                    "1px solid #334155",
                  background:
                    selectedTier ===
                    "ALL"
                      ? "#334155"
                      : "#0f172a",
                  color: "#fff",
                  cursor: "pointer",
                  fontWeight: 700,
                }}
              >
                All Games
              </button>

              {(
                Object.keys(
                  tierInfo
                ) as Tier[]
              ).map((tier) => (
                <button
                  key={tier}
                  aria-pressed={selectedTier === tier}
                  onClick={() =>
                    setSelectedTier(tier)
                  }
                  style={{
                    padding:
                      "8px 14px",
                    borderRadius:
                      "8px",
                    border:
                      "1px solid #334155",
                    background:
                      selectedTier === tier
                        ? tier === "S"
                          ? "#7f1d1d"
                          : tier === "A"
                            ? "#78350f"
                            : tier === "B"
                              ? "#1e3a8a"
                              : tier === "C"
                                ? "#14532d"
                                : "#334155"
                        : "#0f172a",
                    color: "#fff",
                    cursor:
                      "pointer",
                    fontWeight:
                      700,
                  }}
                >
                  {
                    tierInfo[tier]
                      .emoji
                  }{" "}
                  {tier}
                </button>
              ))}
            </div>

            {gamesLoading ? (
              <p
                style={{
                  color:
                    "#94a3b8",
                }}
              >
                Loading games...
              </p>
            ) : (
              <div
                style={{
                  display:
                    "grid",
                  gap: "12px",
                }}
              >
                {filteredGames.map(
                  (game) => {
                    const status =
                      getGameStatus(
                        game
                      );

                    const tier =
                      game.tier;

                    const suggestedTier =
                      game.suggestedTier;

                    const upsetSignal = upsets.find(
                      (upset) => upset.gameId === game.id
                    );
                    const rivalryGame = rivalryGames.find(
                      (item) => item.game.id === game.id
                    );
                    const matchupIndicator = upsetSignal
                      ? {
                          label: `🚨 ${game.completed ? "UPSET" : "UPSET ALERT"} — #${upsetSignal.rank} ${upsetSignal.rankedTeam} lost to ${upsetSignal.opponent} ${upsetSignal.result}`,
                          color: "#f87171",
                        }
                      : rivalryGame
                        ? {
                            label: `🏆 RIVALRY — ${rivalryGame.rivalry.name}${rivalryGame.rivalry.trophy ? ` · ${rivalryGame.rivalry.trophy}` : ""}`,
                            color: "#fbbf24",
                          }
                        : game.top10Matchup
                          ? {
                              label: "🔥 TOP-10 SHOWDOWN",
                              color: "#f97316",
                            }
                          : game.top10VsUnranked
                            ? {
                                label: "💥 RANKING SHOCK WATCH",
                                color: "#fb923c",
                              }
                            : game.rankedMatchup
                              ? {
                                  label: "🏆 RANKED MATCHUP",
                                  color: "#fbbf24",
                                }
                              : game.rankedTeamLost
                                ? {
                                    label: "🚨 RANKED UPSET",
                                    color: "#fbbf24",
                                  }
                                : null;

                    return (
                      <Fragment key={game.id}>
                      <div className="legacy-game-card">
                      <article
                        key={
                          game.id
                        }
                        style={{
                          background:
                            "#0f172a",
                          border:
                            game.homeRank ||
                            game.awayRank
                              ? "1px solid #475569"
                              : "1px solid #1e293b",
                          borderRadius:
                            "12px",
                          padding:
                            "18px",
                        }}
                      >
                        <div
                          style={{
                            display:
                              "flex",
                            justifyContent:
                              "space-between",
                            gap: "16px",
                            flexWrap:
                              "wrap",
                          }}
                        >
                          <div>
                            <div className="cfb-game-indicators-legacy">
                            {upsets
                              .filter(
                                (upset) =>
                                  upset.gameId ===
                                  game.id
                              )
                              .map(
                                (
                                  upset
                                ) => (
                                  <div
                                    key={
                                      upset.gameId
                                    }
                                    style={{
                                      color:
                                        "#f87171",
                                      fontSize:
                                        "13px",
                                      fontWeight:
                                        900,
                                      marginBottom:
                                        "6px",
                                    }}
                                  >
                                    🚨{" "}
                                    {game.completed
                                      ? "UPSET"
                                      : "UPSET ALERT"}{" "}
                                    — #
                                    {
                                      upset.rank
                                    }{" "}
                                    {
                                      upset.rankedTeam
                                    }{" "}
                                    lost to{" "}
                                    {
                                      upset.opponent
                                    }{" "}
                                    {
                                      upset.result
                                    }
                                  </div>
                                )
                              )}

                            {rivalryGames
                              .filter(
                                (item) =>
                                  item.game.id ===
                                  game.id
                              )
                              .map(
                                (
                                  item
                                ) => (
                                  <div
                                    key={
                                      item.game.id
                                    }
                                    style={{
                                      color:
                                        "#fbbf24",
                                      fontSize:
                                        "13px",
                                      fontWeight:
                                        900,
                                      marginBottom:
                                        "6px",
                                    }}
                                  >
                                    🏆 RIVALRY —{" "}
                                    {
                                      item.rivalry
                                        .name
                                    }
                                    {item
                                      .rivalry
                                      .trophy
                                      ? ` · ${item.rivalry.trophy}`
                                      : ""}
                                  </div>
                                )
                              )}

                            {game.top10Matchup && (
                              <div
                                style={{
                                  color:
                                    "#f97316",
                                  fontSize:
                                    "13px",
                                  fontWeight:
                                    800,
                                  marginBottom:
                                    "6px",
                                }}
                              >
                                🔥 TOP-10 SHOWDOWN
                              </div>
                            )}

                            {game.top10VsUnranked && (
                              <div
                                style={{
                                  color:
                                    "#fb923c",
                                  fontSize:
                                    "13px",
                                  fontWeight:
                                    800,
                                  marginBottom:
                                    "6px",
                                }}
                              >
                                💥 RANKING SHOCK WATCH
                              </div>
                            )}

                            {game.rankedMatchup && (
                              <div
                                style={{
                                  color:
                                    "#fbbf24",
                                  fontSize:
                                    "13px",
                                  fontWeight:
                                    800,
                                  marginBottom:
                                    "6px",
                                }}
                              >
                                🏆 RANKED MATCHUP
                              </div>
                            )}

                            {game.rankedTeamLost && (
                              <div
                                style={{
                                  fontWeight:
                                    800,
                                  fontSize:
                                    "14px",
                                  color:
                                    "#fbbf24",
                                  marginBottom:
                                    "6px",
                                }}
                              >
                                🚨 RANKED UPSET
                              </div>
                            )}
                            </div>

                            <div
                              style={{
                                color:
                                  "#64748b",
                                fontSize:
                                  "13px",
                                marginBottom:
                                  "8px",
                              }}
                            >
                              {formatGameTime(
                                game.startDate
                              )}{" "}
                              ·{" "}
                              {status}
                            </div>

                            <div
                              style={{
                                fontSize:
                                  "20px",
                                fontWeight:
                                  800,
                              }}
                            >
                              {game.awayRank &&
                                `#${game.awayRank} `}
                              {
                                game.awayTeam
                              }{" "}
                              {game.awayPoints ??
                                "—"}
                            </div>

                            <div
                              style={{
                                fontSize:
                                  "20px",
                                fontWeight:
                                  800,
                                marginTop:
                                  "4px",
                              }}
                            >
                              {game.homeRank &&
                                `#${game.homeRank} `}
                              {
                                game.homeTeam
                              }{" "}
                              {game.homePoints ??
                                "—"}
                            </div>

                            {matchupIndicator && (
                              <div
                                className="command-center__matchup-indicator"
                                style={{
                                  color: matchupIndicator.color,
                                }}
                              >
                                {matchupIndicator.label}
                              </div>
                            )}
                          </div>

                          <div
                            style={{
                              display:
                                "flex",
                              flexDirection:
                                "column",
                              gap: "6px",
                              alignItems:
                                "flex-end",
                            }}
                          >
                            {tier ? (
                              <div
                                style={{
                                  fontWeight:
                                    800,
                                  fontSize:
                                    "14px",
                                }}
                              >
                                {
                                  tierInfo[
                                    tier
                                  ].emoji
                                }{" "}
                                {tier} ·{" "}
                                {
                                  tierInfo[
                                    tier
                                  ].name
                                }
                              </div>
                            ) : (
                              <div
                                style={{
                                  fontWeight:
                                    800,
                                  fontSize:
                                    "14px",
                                  color:
                                    suggestedTier ===
                                    "S"
                                      ? "#f97316"
                                      : suggestedTier ===
                                        "A"
                                        ? "#fbbf24"
                                        : suggestedTier ===
                                          "B"
                                          ? "#60a5fa"
                                          : "#94a3b8",
                                }}
                              >
                                Suggested:{" "}
                                {
                                  suggestedTier
                                }
                              </div>
                            )}

                            <div
                              style={{
                                display:
                                  "flex",
                                gap:
                                  "6px",
                                flexWrap:
                                  "wrap",
                                justifyContent:
                                  "flex-end",
                              }}
                            >
                              {(
                                Object.keys(
                                  tierInfo
                                ) as Tier[]
                              ).map(
                                (
                                  tierOption
                                ) => (
                                  <button
                                    key={
                                      tierOption
                                    }
                                    onClick={() =>
                                      setGameTier(
                                        game.id,
                                        tierOption
                                      )
                                    }
                                    style={{
                                      border:
                                        tiers[
                                          game.id
                                        ] ===
                                        tierOption
                                          ? "2px solid #ffffff"
                                          : "1px solid #334155",
                                      backgroundColor:
                                        tiers[
                                          game.id
                                        ] ===
                                        tierOption
                                          ? tierOption ===
                                            "S"
                                            ? "#ef4444"
                                            : tierOption ===
                                              "A"
                                              ? "#f59e0b"
                                              : tierOption ===
                                                "B"
                                                ? "#3b82f6"
                                                : tierOption ===
                                                  "C"
                                                  ? "#22c55e"
                                                  : "#64748b"
                                          : "#020617",
                                      color:
                                        "#ffffff",
                                      borderRadius:
                                        "6px",
                                      padding:
                                        "6px 9px",
                                      cursor:
                                        "pointer",
                                      fontWeight:
                                        700,
                                    }}
                                  >
                                    {
                                      tierOption
                                    }
                                  </button>
                                )
                              )}
                            </div>
                          </div>
                        </div>
                      </article>
                      </div>
                      <GameCard
                        status={status}
                        awayTeam={game.awayTeam}
                        awayMeta={game.awayRank ? `#${game.awayRank}` : "Unranked"}
                        awayScore={game.awayPoints}
                        homeTeam={game.homeTeam}
                        homeMeta={game.homeRank ? `#${game.homeRank}` : "Unranked"}
                        homeScore={game.homePoints}
                        time={formatGameTime(game.startDate)}
                        indicator={matchupIndicator}
                        footer={
                          <div className="game-card__tier-controls">
                            <div className="game-card__tier-label">
                              {tier
                                ? `${tierInfo[tier].emoji} ${tier} · ${tierInfo[tier].name}`
                                : `Suggested: ${suggestedTier} · ${tierInfo[suggestedTier].name}`}
                            </div>
                            <div className="game-card__tier-buttons">
                              {(Object.keys(tierInfo) as Tier[]).map((tierOption) => (
                                <button
                                  key={tierOption}
                                  aria-pressed={tier === tierOption}
                                  onClick={() => setGameTier(game.id, tierOption)}
                                >
                                  {tierOption}
                                </button>
                              ))}
                            </div>
                          </div>
                        }
                      />
                      </Fragment>
                    );
                  }
                )}
              </div>
            )}

          </section>
        )}

        {activeTab === "performances" && (
          <section>
            <div
              style={{
                background:
                  "#0f172a",
                border:
                  "1px solid #1e293b",
                borderRadius:
                  "12px",
                padding:
                  "20px",
              }}
            >
              <h2
                style={{
                  marginTop: 0,
                  marginBottom:
                    "6px",
                }}
              >
                💥 Big Performances
              </h2>

              {showMilestones && milestones.length > 0 && (
                <div
                  style={{
                    marginBottom:
                      "16px",
                    padding:
                      "14px 16px",
                    borderRadius:
                      "10px",
                    border:
                      "1px solid #fbbf24",
                    background:
                      "#17130a",
                  }}
                >
                  <div
                    style={{
                      color:
                        "#fbbf24",
                      fontWeight:
                        900,
                      fontSize:
                        "14px",
                      marginBottom:
                        "8px",
                    }}
                  >
                    🏆 STATISTICAL
                    MILESTONES
                  </div>

                  {milestones.map(
                    (
                      milestone
                    ) => (
                      <div
                        key={`${milestone.player}-${milestone.gameId}-${milestone.stat}`}
                        style={{
                          color:
                            "#f8fafc",
                          fontWeight:
                            700,
                          marginTop:
                            "6px",
                        }}
                      >
                        {
                          milestone.player
                        }{" "}
                        ·{" "}
                        {
                          milestone.team
                        }{" "}
                        —{" "}
                        {
                          milestone.message
                        }{" "}
                        vs.{" "}
                        {
                          milestone.opponent
                        }
                      </div>
                    )
                  )}
                </div>
              )}

              <p
                style={{
                  color:
                    "#94a3b8",
                  marginTop: 0,
                }}
              >
                Ridiculous single-game
                performances worth
                checking for social
                content.
              </p>

              {playerStatsLoading ? (
                <p
                  style={{
                    color:
                      "#94a3b8",
                  }}
                >
                  Loading player
                  performances...
                </p>
              ) : bigPerformances.length ===
                0 ? (
                <p
                  style={{
                    color:
                      "#94a3b8",
                  }}
                >
                  No monster
                  performances
                  detected yet.
                </p>
              ) : (
                <div
                  style={{
                    display:
                      "grid",
                    gap:
                      "12px",
                  }}
                >
                  {bigPerformances.map(
                    (
                      performance
                    ) => (
                      <div
                        key={
                          performance.id
                        }
                        style={{
                          padding:
                            "18px",
                          border:
                            "1px solid #334155",
                          borderRadius:
                            "10px",
                          background:
                            "#020617",
                        }}
                      >
                        <div
                          style={{
                            display:
                              "flex",
                            justifyContent:
                              "space-between",
                            gap:
                              "16px",
                            flexWrap:
                              "wrap",
                          }}
                        >
                          <div>
                            <div
                              style={{
                                fontSize:
                                  "20px",
                                fontWeight:
                                  800,
                              }}
                            >
                              🔥{" "}
                              {
                                performance.player
                              }{" "}
                              ·{" "}
                              {
                                performance.team
                              }
                            </div>

                            <div
                              style={{
                                color:
                                  "#cbd5e1",
                                marginTop:
                                  "6px",
                              }}
                            >
                              vs.{" "}
                              {
                                performance.opponent
                              }
                            </div>
                          </div>

                          <div
                            style={{
                              color:
                                "#fbbf24",
                              fontWeight:
                                800,
                              fontSize:
                                "16px",
                            }}
                          >
                            {
                              getPerformanceResult(
                                performance
                              )
                            }
                          </div>
                        </div>

                        <div
                          style={{
                            display:
                              "flex",
                            gap:
                              "10px",
                            flexWrap:
                              "wrap",
                            marginTop:
                              "16px",
                          }}
                        >
                          {performance.stats.map(
                            (stat) => (
                              <div
                                key={`${stat.category}-${stat.stat}`}
                                style={{
                                  padding:
                                    "10px 14px",
                                  borderRadius:
                                    "8px",
                                  background:
                                    "#0f172a",
                                  border:
                                    "1px solid #1e293b",
                                  minWidth:
                                    "110px",
                                }}
                              >
                                <div
                                  style={{
                                    color:
                                      "#94a3b8",
                                    fontSize:
                                      "11px",
                                    textTransform:
                                      "uppercase",
                                    fontWeight:
                                      700,
                                    letterSpacing:
                                      "0.04em",
                                  }}
                                >
                                  {
                                    getStatLabel(
                                      stat
                                    )
                                  }
                                </div>

                                <div
                                  style={{
                                    fontSize:
                                      "18px",
                                    fontWeight:
                                      800,
                                    marginTop:
                                      "4px",
                                  }}
                                >
                                  {
                                    formatPlayerStat(
                                      stat
                                    )
                                  }
                                </div>
                              </div>
                            )
                          )}
                        </div>

                        <div
                          style={{
                            marginTop:
                              "16px",
                            padding:
                              "12px 14px",
                            borderRadius:
                              "8px",
                            background:
                              "#111827",
                            border:
                              "1px solid #334155",
                          }}
                        >
                          <div
                            style={{
                              color:
                                "#60a5fa",
                              fontSize:
                                "11px",
                              fontWeight:
                                900,
                              letterSpacing:
                                "0.05em",
                              marginBottom:
                                "6px",
                            }}
                          >
                            📣 CONTENT ANGLE
                          </div>

                          <div
                            style={{
                              color:
                                "#e2e8f0",
                              fontWeight:
                                700,
                              lineHeight:
                                1.5,
                            }}
                          >
                            {
                              performance.player
                            }{" "}
                            just put up{" "}
                            {
                              performance.reason
                            }{" "}
                            against{" "}
                            {
                              performance.opponent
                            }{" "}
                            —{" "}
                            {getPerformanceResult(
                              performance
                            )}
                            .
                          </div>
                        </div>
                      </div>
                    )
                  )}
                </div>
              )}
            </div>
          </section>
        )}

        {activeTab === "stats" && (
          <section>
            <div
              style={{
                display:
                  "flex",
                gap: "8px",
                marginBottom:
                  "18px",
                flexWrap:
                  "wrap",
              }}
            >
              <button
                aria-pressed={statsView === "individual"}
                onClick={() =>
                  changeStatsView(
                    "individual"
                  )
                }
                style={{
                  padding:
                    "10px 14px",
                  borderRadius:
                    "8px",
                  border:
                    "1px solid #334155",
                  background:
                    statsView ===
                    "individual"
                      ? "#334155"
                      : "#0f172a",
                  color: "#fff",
                  cursor:
                    "pointer",
                  fontWeight:
                    700,
                }}
              >
                Individual
              </button>

              <button
                aria-pressed={statsView === "team"}
                onClick={() =>
                  changeStatsView(
                    "team"
                  )
                }
                style={{
                  padding:
                    "10px 14px",
                  borderRadius:
                    "8px",
                  border:
                    "1px solid #334155",
                  background:
                    statsView ===
                    "team"
                      ? "#334155"
                      : "#0f172a",
                  color: "#fff",
                  cursor:
                    "pointer",
                  fontWeight:
                    700,
                }}
              >
                Team
              </button>

              <button
                aria-pressed={statsMode === "weekly"}
                onClick={() =>
                  changeStatsMode(
                    "weekly"
                  )
                }
                style={{
                  padding:
                    "10px 14px",
                  borderRadius:
                    "8px",
                  border:
                    "1px solid #334155",
                  background:
                    statsMode ===
                    "weekly"
                      ? "#334155"
                      : "#0f172a",
                  color: "#fff",
                  cursor:
                    "pointer",
                  fontWeight:
                    700,
                }}
              >
                Weekly
              </button>

              <button
                aria-pressed={statsMode === "season"}
                onClick={() =>
                  changeStatsMode(
                    "season"
                  )
                }
                style={{
                  padding:
                    "10px 14px",
                  borderRadius:
                    "8px",
                  border:
                    "1px solid #334155",
                  background:
                    statsMode ===
                    "season"
                      ? "#334155"
                      : "#0f172a",
                  color: "#fff",
                  cursor:
                    "pointer",
                  fontWeight:
                    700,
                }}
              >
                Season
              </button>
            </div>

            <div
              style={{
                display:
                  "flex",
                gap:
                  "8px",
                flexWrap:
                  "wrap",
                marginBottom:
                  "20px",
              }}
            >
              {currentCategories.map(
                (
                  category
                ) => (
                  <button
                    key={
                      category.id
                    }
                    aria-pressed={selectedCategory === category.id}
                    onClick={() =>
                      setSelectedCategory(
                        category.id
                      )
                    }
                    style={{
                      padding:
                        "8px 12px",
                      borderRadius:
                        "8px",
                      border:
                        "1px solid #334155",
                      background:
                        selectedCategory ===
                        category.id
                          ? "#1e293b"
                          : "#0f172a",
                      color:
                        "#f8fafc",
                      cursor:
                        "pointer",
                    }}
                  >
                    {
                      category.name
                    }
                  </button>
                )
              )}
            </div>

            <div
              style={{
                background:
                  "#0f172a",
                border:
                  "1px solid #1e293b",
                borderRadius:
                  "12px",
                overflow:
                  "hidden",
              }}
            >
              <div
                style={{
                  padding:
                    "18px",
                  borderBottom:
                    "1px solid #1e293b",
                }}
              >
                <h2
                  style={{
                    margin: 0,
                    fontSize:
                      "22px",
                  }}
                >
                  {statsView ===
                  "team"
                    ? "Team"
                    : "Individual"}{" "}
                  {
                    currentCategories.find(
                      (
                        category
                      ) =>
                        category.id ===
                        selectedCategory
                    )?.name ??
                    ""
                  }
                </h2>

                <p
                  style={{
                    color:
                      "#94a3b8",
                    marginBottom:
                      0,
                  }}
                >
                  {statsMode ===
                  "season"
                    ? "2026 season leaders"
                    : "Current ESPN week leaders"}
                </p>
              </div>

              {statsMode ===
                "weekly" &&
              playerStatsLoading ? (
                <p
                  style={{
                    padding:
                      "20px",
                    color:
                      "#94a3b8",
                  }}
                >
                  Loading weekly
                  stats...
                </p>
              ) : statsMode ===
                  "season" &&
                seasonStatsLoading ? (
                <p
                  style={{
                    padding:
                      "20px",
                    color:
                      "#94a3b8",
                  }}
                >
                  Loading season
                  stats...
                </p>
              ) : weeklyUnavailable ? (
                <p
                  style={{
                    padding:
                      "20px",
                    color:
                      "#94a3b8",
                  }}
                >
                  That weekly team
                  category isn't
                  available from the
                  current ESPN player
                  box-score feed.
                </p>
              ) : (
                <div
                  style={{
                    overflowX:
                      "auto",
                  }}
                >
                  <table
                    style={{
                      width:
                        "100%",
                      borderCollapse:
                        "collapse",
                    }}
                  >
                    <thead>
                      <tr>
                        <th
                          style={
                            thStyle
                          }
                        >
                          Rank
                        </th>

                        <th
                          style={
                            thStyle
                          }
                        >
                          {statsView ===
                          "team"
                            ? "Team"
                            : "Player"}
                        </th>

                        {statsView ===
                          "individual" && (
                          <th
                            style={
                              thStyle
                            }
                          >
                            Team
                          </th>
                        )}

                        <th
                          style={
                            thStyle
                          }
                        >
                          Value
                        </th>
                      </tr>
                    </thead>

                    <tbody>
                      {leaders
                        .slice(
                          0,
                          25
                        )
                        .map(
                          (
                            leader,
                            index
                          ) => (
                            <tr
                              key={
                                leader.playerId
                              }
                            >
                              <td
                                style={
                                  tdStyle
                                }
                              >
                                {index +
                                  1}
                              </td>

                              <td
                                style={{
                                  ...tdStyle,
                                  fontWeight:
                                    700,
                                }}
                              >
                                {
                                  leader.player
                                }
                              </td>

                              {statsView ===
                                "individual" && (
                                <td
                                  style={
                                    tdStyle
                                  }
                                >
                                  {
                                    leader.team
                                  }
                                </td>
                              )}

                              <td
                                style={{
                                  ...tdStyle,
                                  fontWeight:
                                    800,
                                }}
                              >
                                {statsMode ===
  "season" &&
statsView ===
  "team"
  ? selectedCategory === "total-defense" ||
selectedCategory === "rushing-defense" ||
selectedCategory === "passing-defense" ||
selectedCategory === "scoring-defense"
  ? `${leader.value.toLocaleString()} YPG`
  : formatStatValue(
      selectedCategory,
      leader.value
    )
  : statsMode ===
    "season" &&
  statsView ===
    "individual" &&
  selectedCategory.endsWith(
    "-td"
  )
  ? `${leader.value.toLocaleString()} TD`
  : statsMode ===
      "season" &&
    statsView ===
      "individual" &&
    selectedCategory === "tackles"
    ? `${leader.value.toLocaleString()} tackles`
    : statsMode ===
        "season" &&
      statsView ===
        "individual" &&
      selectedCategory === "sacks"
      ? `${leader.value.toLocaleString()} sacks`
      : `${leader.value.toLocaleString()} yards`}
                              </td>
                            </tr>
                          )
                        )}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          </section>
        )}

        {activeTab === "all-time" && (
  <section>
    <div
      style={{
        background: "#0f172a",
        border: "1px solid #1e293b",
        borderRadius: "12px",
        padding: "24px",
      }}
    >
      <h2
        style={{
          marginTop: 0,
          marginBottom: "8px",
        }}
      >
        🏆 All-Time
      </h2>

      <p
        style={{
          color: "#94a3b8",
          marginTop: 0,
          lineHeight: 1.6,
        }}
      >
        NCAA historical football records and career
        milestones.
      </p>

      <div
        style={{
          display: "grid",
          gridTemplateColumns:
            "repeat(auto-fit, minmax(220px, 1fr))",
          gap: "12px",
          marginTop: "20px",
        }}
      >
        {[
          {
            title: "🏃 Career Rushing",
            description:
              "All-time career rushing-yard records.",
          },
          {
            title: "🏈 Career Passing",
            description:
              "All-time career passing-yard records.",
          },
          {
            title: "🙌 Career Receiving",
            description:
              "All-time career receiving-yard records.",
          },
          {
            title: "🔥 Career Touchdowns",
            description:
              "Historical career touchdown records.",
          },
          {
            title: "🎯 Career Scoring",
            description:
              "Historical career scoring records.",
          },
          {
            title: "📚 NCAA Records",
            description:
              "Official NCAA football record-book context.",
          },
        ].map((record) => (
          <div
            key={record.title}
            style={{
              background: "#111827",
              border: "1px solid #334155",
              borderRadius: "10px",
              padding: "18px",
            }}
          >
            <div
              style={{
                fontSize: "16px",
                fontWeight: 800,
                marginBottom: "8px",
              }}
            >
              {record.title}
            </div>

            <div
              style={{
                color: "#94a3b8",
                fontSize: "14px",
                lineHeight: 1.5,
              }}
            >
              {record.description}
            </div>
          </div>
        ))}
      </div>

      <div
        style={{
          marginTop: "20px",
          padding: "14px 16px",
          background: "#111827",
          border: "1px solid #334155",
          borderRadius: "10px",
          color: "#cbd5e1",
          lineHeight: 1.6,
          fontSize: "14px",
        }}
      >
        <strong style={{ color: "#f8fafc" }}>
          Data source:
        </strong>{" "}
        NCAA official football records and record books.
        The NCAA maintains historical individual and team
        records across college football divisions.
      </div>
    </div>
  </section>
)}
      </div>
    </main>
  );
}

const thStyle: React.CSSProperties = {
  textAlign: "left",
  padding: "14px 18px",
  color: "#94a3b8",
  fontSize: "13px",
  textTransform: "uppercase",
  letterSpacing: "0.05em",
  borderBottom:
    "1px solid #1e293b",
};

const tdStyle: React.CSSProperties = {
  padding: "14px 18px",
  borderBottom:
    "1px solid #1e293b",
};
